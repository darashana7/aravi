import asyncio
from playwright.async_api import async_playwright

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page()

        pages_to_verify = ["about.html", "services.html", "projects.html", "contact.html"]

        for page_name in pages_to_verify:
            await page.goto(f"http://localhost:8000/{page_name}")
            await page.screenshot(path=f"screenshot-{page_name}.png")

        await browser.close()

if __name__ == "__main__":
    asyncio.run(main())
